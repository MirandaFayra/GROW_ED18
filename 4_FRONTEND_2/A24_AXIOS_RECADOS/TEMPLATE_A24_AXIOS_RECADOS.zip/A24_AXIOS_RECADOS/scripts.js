

const messagesContainer = document.getElementById('messagesContainer');

//----------- CRIAR MENSAGEM ------------

const createMessage = async (event) => {

    try {
        
        

    } catch (error) {

    }
};




//----------- PEGAR MENSAGEM ------------


const getMessages = (event) =>{
    event.preventDefault()

    //Pegamos o valor passado no parametro
    const email = document.getElementById('emailInput').value
    console.log(email)

    // fazemos o enpoint
    api.get(`massage/${email}`)

    .then(function(response ){
        console.log('Entrei no then')
        console.log(response.data.data)

        //salvamos o array de resposta em uma variável 
        const messages = response.data.data;
        
        //Interamos o array para criar uma div com as informacoes
        messages.forEach(message => {
          const messageElement = document.createElement('div')

          messageElement.innerHTML = `
            <p> Id : ${message.id}</p>
            <p> Título: ${message.title}</p>
            <p> Descrição: ${message.description}</p>
          `
          //Adiciona um Elemento no container
          messagesContainer.appendChild(messageElement)
        })
    })
    .catch(function(error){
        console.log(`Essa é a mensagem de erro '  ${error.message}`)
    
    })
} 



//----------- ATUALIZAR MENSAGEM ------------

const atualizarMensagem = async (event) => {
    event.preventDefault()

    try {
       

    } catch (error) {

    }
}

//----------- DELETAR  MENSAGEM ------------

const deletarMensagem = async(event) =>{

    try {
       
    } catch (error) {
        
    }
   

}

//----------- LOGIN NA API EX ------------